package gg.novatiers.mod.mixin;

import gg.novatiers.mod.NovaTiersClientMod;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void novatiers$tabTier(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        Text original = cir.getReturnValue();
        if (original == null || entry == null) return;

        Text badge = NovaTiersClientMod.buildPlayerPrefix(entry.getProfile().name(), false);
        if (badge != null) {
            cir.setReturnValue(Text.empty().append(badge).append(original));
        }
    }
}
