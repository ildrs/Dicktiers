package gg.novatiers.mod;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class TierColorHelper {
    public static final List<String> ALL_MODES = List.of(
            "overall", "vanilla", "sword", "uhc", "nethpot",
            "smp", "axe", "diapot", "mace", "spearmace"
    );

    public static final List<String> PLAYABLE_MODES = List.of(
            "vanilla", "sword", "uhc", "nethpot",
            "smp", "axe", "diapot", "mace", "spearmace"
    );

    private static final Map<String, String> MODE_LABELS = Map.ofEntries(
            Map.entry("overall", "Geral"),
            Map.entry("vanilla", "Crystal"),
            Map.entry("sword", "Sword"),
            Map.entry("uhc", "UHC"),
            Map.entry("nethpot", "NethPot"),
            Map.entry("smp", "SMP"),
            Map.entry("axe", "Axe"),
            Map.entry("diapot", "DiaPot"),
            Map.entry("mace", "Mace"),
            Map.entry("spearmace", "Spear Mace")
    );

    private TierColorHelper() {}

    public static boolean isValidMode(String raw) {
        if (raw == null) return false;
        String norm = normalizeMode(raw);
        return ALL_MODES.contains(norm);
    }

    public static String normalizeMode(String raw) {
        if (raw == null) return "overall";
        String lower = raw.trim().toLowerCase(Locale.ROOT);
        if (lower.equals("crystal") || lower.equals("cpvp")) return "vanilla";
        if (lower.equals("spear") || lower.equals("spear_mace") || lower.equals("spear-mace")) {
            return "spearmace";
        }
        return lower;
    }

    public static String getModeLabel(String mode) {
        return MODE_LABELS.getOrDefault(normalizeMode(mode), mode);
    }

    public static int getTierColorHex(String tier) {
        if (tier == null) return 0x94A3B8;
        return switch (tier.toUpperCase(Locale.ROOT)) {
            case "HT1" -> 0xFBBF24; // Gold / Amber
            case "LT1" -> 0xF59E0B;
            case "HT2" -> 0xE2E8F0; // Platinum / Silver
            case "LT2" -> 0xCBD5E1;
            case "HT3" -> 0xFB923C; // Bronze / Orange
            case "LT3" -> 0xF97316;
            case "HT4" -> 0x38BDF8; // Diamond / Sky
            case "LT4" -> 0x0EA5E9;
            case "HT5" -> 0xA1A1AA; // Iron / Zinc
            case "LT5" -> 0x71717A;
            default -> 0x94A3B8;
        };
    }

    public static int getTierOrderIndex(String tier) {
        if (tier == null) return 999;
        return switch (tier.toUpperCase(Locale.ROOT)) {
            case "HT1" -> 0;
            case "LT1" -> 1;
            case "HT2" -> 2;
            case "LT2" -> 3;
            case "HT3" -> 4;
            case "LT3" -> 5;
            case "HT4" -> 6;
            case "LT4" -> 7;
            case "HT5" -> 8;
            case "LT5" -> 9;
            default -> 999;
        };
    }

    public static MutableText formatBadge(String tier, String suffixLabel) {
        int color = getTierColorHex(tier);
        MutableText bracketOpen = Text.literal("[").setStyle(Style.EMPTY.withColor(0x64748B));
        MutableText rankText = Text.literal(tier.toUpperCase(Locale.ROOT))
                .setStyle(Style.EMPTY.withColor(color).withBold(true));
        MutableText result = Text.empty().append(bracketOpen).append(rankText);
        if (suffixLabel != null && !suffixLabel.isEmpty()) {
            result.append(Text.literal(" " + suffixLabel).setStyle(Style.EMPTY.withColor(0x94A3B8)));
        }
        result.append(Text.literal("] ").setStyle(Style.EMPTY.withColor(0x64748B)));
        return result;
    }
}
