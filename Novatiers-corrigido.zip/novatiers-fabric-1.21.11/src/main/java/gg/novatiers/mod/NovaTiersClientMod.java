package gg.novatiers.mod;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.Map;

public class NovaTiersClientMod implements ClientModInitializer {
    private static NovaTiersConfig config;
    private static TierApiService apiService;
    private int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        config = NovaTiersConfig.load();
        apiService = new TierApiService();

        // Initial background sync
        apiService.refreshAllAsync(config.apiBaseUrl);

        // Periodic refresh on client ticks (20 ticks/sec)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null) return;
            tickCounter++;
            int intervalTicks = Math.max(600, config.refreshIntervalSeconds * 20);
            if (tickCounter >= intervalTicks) {
                tickCounter = 0;
                apiService.refreshAllAsync(config.apiBaseUrl);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(buildRootCommand("novatiers"));
            dispatcher.register(buildTierShortcutCommand("tier"));
        });
    }

    public static NovaTiersConfig getConfig() {
        return config;
    }

    public static TierApiService getApiService() {
        return apiService;
    }

    public static Text buildPlayerPrefix(String playerName, boolean isNametag) {
        if (config == null || apiService == null || !config.enabled) return null;
        if (isNametag && !config.showInNametag) return null;
        if (!isNametag && !config.showInTabList) return null;

        TierApiService.PlayerTierData data = apiService.getCachedPlayer(playerName);
        if (data == null) return null;

        String tier = data.getTierForMode(config.activeMode);
        if (tier == null || tier.isBlank()) return null;

        String suffix = null;
        if ("overall".equals(config.activeMode) && config.showPointsInOverall && data.points > 0) {
            suffix = data.points + "pts";
        }
        return TierColorHelper.formatBadge(tier, suffix);
    }

    private LiteralArgumentBuilder<FabricClientCommandSource> buildRootCommand(String literal) {
        return ClientCommandManager.literal(literal)
                .executes(ctx -> {
                    sendStatus(ctx.getSource());
                    return 1;
                })
                .then(ClientCommandManager.literal("refresh")
                        .executes(ctx -> {
                            FabricClientCommandSource src = ctx.getSource();
                            src.sendFeedback(prefix().append(Text.literal("Sincronizando Nova Tiers...")
                                    .setStyle(Style.EMPTY.withColor(0xCBD5E1))));
                            apiService.refreshAllAsync(config.apiBaseUrl).whenComplete((count, err) -> {
                                MinecraftClient.getInstance().execute(() -> {
                                    if (err != null) {
                                        src.sendError(prefix().append(Text.literal(
                                                "Erro ao sincronizar: " + err.getMessage())));
                                    } else {
                                        src.sendFeedback(prefix().append(Text.literal(
                                                "Tier list atualizada! (" + count + " jogadores carregados)")
                                                .setStyle(Style.EMPTY.withColor(0x34D399))));
                                    }
                                });
                            });
                            return 1;
                        }))
                .then(ClientCommandManager.literal("mode")
                        .then(ClientCommandManager.argument("modo", StringArgumentType.word())
                                .suggests((context, builder) -> {
                                    for (String m : TierColorHelper.ALL_MODES) {
                                        builder.suggest(m);
                                    }
                                    return builder.buildFuture();
                                })
                                .executes(ctx -> {
                                    String raw = StringArgumentType.getString(ctx, "modo");
                                    if (!TierColorHelper.isValidMode(raw)) {
                                        ctx.getSource().sendError(prefix().append(Text.literal(
                                                "Modo inválido. Use: " + String.join(", ", TierColorHelper.ALL_MODES))));
                                        return 0;
                                    }
                                    config.activeMode = TierColorHelper.normalizeMode(raw);
                                    config.save();
                                    ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                            "Modo de exibição alterado para: " + TierColorHelper.getModeLabel(config.activeMode))
                                            .setStyle(Style.EMPTY.withColor(0xFBBF24))));
                                    return 1;
                                })))
                .then(ClientCommandManager.literal("toggle")
                        .executes(ctx -> {
                            config.enabled = !config.enabled;
                            config.save();
                            ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                    config.enabled ? "Nova Tiers ativado." : "Nova Tiers desativado.")
                                    .setStyle(Style.EMPTY.withColor(config.enabled ? 0x34D399 : 0xF87171))));
                            return 1;
                        })
                        .then(ClientCommandManager.literal("nametag").executes(ctx -> {
                            config.showInNametag = !config.showInNametag;
                            config.save();
                            ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                    "Badges na nametag: " + (config.showInNametag ? "ATIVADO" : "DESATIVADO"))
                                    .setStyle(Style.EMPTY.withColor(0xFBBF24))));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("tab").executes(ctx -> {
                            config.showInTabList = !config.showInTabList;
                            config.save();
                            ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                    "Badges no Tab: " + (config.showInTabList ? "ATIVADO" : "DESATIVADO"))
                                    .setStyle(Style.EMPTY.withColor(0xFBBF24))));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("points").executes(ctx -> {
                            config.showPointsInOverall = !config.showPointsInOverall;
                            config.save();
                            ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                    "Pontos no modo Geral: " + (config.showPointsInOverall ? "ATIVADO" : "DESATIVADO"))
                                    .setStyle(Style.EMPTY.withColor(0xFBBF24))));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("url")
                        .then(ClientCommandManager.argument("apiUrl", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    String rawUrl = StringArgumentType.getString(ctx, "apiUrl").trim();
                                    if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) {
                                        ctx.getSource().sendError(prefix().append(Text.literal(
                                                "A URL deve começar com https:// ou http://")));
                                        return 0;
                                    }
                                    config.apiBaseUrl = rawUrl;
                                    config.save();
                                    ctx.getSource().sendFeedback(prefix().append(Text.literal(
                                            "URL da API atualizada. Sincronizando...")
                                            .setStyle(Style.EMPTY.withColor(0xFBBF24))));
                                    apiService.refreshAllAsync(config.apiBaseUrl);
                                    return 1;
                                })))
                .then(ClientCommandManager.literal("lookup")
                        .then(ClientCommandManager.argument("nick", StringArgumentType.word())
                                .executes(ctx -> lookupAndPrint(ctx.getSource(), StringArgumentType.getString(ctx, "nick")))));
    }

    private LiteralArgumentBuilder<FabricClientCommandSource> buildTierShortcutCommand(String literal) {
        return ClientCommandManager.literal(literal)
                .then(ClientCommandManager.argument("nick", StringArgumentType.word())
                        .executes(ctx -> lookupAndPrint(ctx.getSource(), StringArgumentType.getString(ctx, "nick"))));
    }

    private int lookupAndPrint(FabricClientCommandSource src, String nick) {
        TierApiService.PlayerTierData cached = apiService.getCachedPlayer(nick);
        if (cached != null) {
            printPlayerCard(src, cached);
            return 1;
        }

        src.sendFeedback(prefix().append(Text.literal("Buscando " + nick + " na Nova Tiers...")
                .setStyle(Style.EMPTY.withColor(0x94A3B8))));

        apiService.fetchSinglePlayerAsync(config.apiBaseUrl, nick).whenComplete((data, err) -> {
            MinecraftClient.getInstance().execute(() -> {
                if (err != null) {
                    src.sendError(prefix().append(Text.literal("Erro ao consultar jogador: " + err.getMessage())));
                } else if (data == null) {
                    src.sendFeedback(prefix().append(Text.literal(
                            "Jogador \"" + nick + "\" não possui tiers registrados na Nova Tiers.")
                            .setStyle(Style.EMPTY.withColor(0xF87171))));
                } else {
                    printPlayerCard(src, data);
                }
            });
        });
        return 1;
    }

    private void printPlayerCard(FabricClientCommandSource src, TierApiService.PlayerTierData data) {
        MutableText header = prefix()
                .append(Text.literal(data.name).setStyle(Style.EMPTY.withColor(0xFFFFFF).withBold(true)))
                .append(Text.literal(" · " + data.points + " pts · " + data.combatTitle + " (" + data.region + ")")
                        .setStyle(Style.EMPTY.withColor(0xFBBF24)));
        if (data.guild != null && !data.guild.isEmpty()) {
            header.append(Text.literal(" · Guilda: " + data.guild).setStyle(Style.EMPTY.withColor(0x94A3B8)));
        }
        src.sendFeedback(header);

        MutableText modesLine = Text.literal("  Modos: ").setStyle(Style.EMPTY.withColor(0x94A3B8));
        boolean any = false;
        for (String mode : TierColorHelper.PLAYABLE_MODES) {
            String tier = data.tiers.get(mode);
            if (tier != null) {
                if (any) {
                    modesLine.append(Text.literal(" · ").setStyle(Style.EMPTY.withColor(0x475569)));
                }
                any = true;
                modesLine.append(Text.literal(TierColorHelper.getModeLabel(mode) + ": ")
                        .setStyle(Style.EMPTY.withColor(0xCBD5E1)));
                modesLine.append(Text.literal(tier)
                        .setStyle(Style.EMPTY.withColor(TierColorHelper.getTierColorHex(tier)).withBold(true)));
            }
        }
        if (!any) {
            modesLine.append(Text.literal("Nenhum tier ativo").setStyle(Style.EMPTY.withColor(0x64748B)));
        }
        src.sendFeedback(modesLine);
    }

    private void sendStatus(FabricClientCommandSource src) {
        src.sendFeedback(prefix()
                .append(Text.literal("Modo: " + TierColorHelper.getModeLabel(config.activeMode))
                        .setStyle(Style.EMPTY.withColor(0xFBBF24)))
                .append(Text.literal(" · Jogadores em cache: " + apiService.getCachedCount())
                        .setStyle(Style.EMPTY.withColor(0xCBD5E1))));
        src.sendFeedback(Text.literal("  Comandos: /tier <nick> | /novatiers mode <modo> | /novatiers toggle <nametag|tab|points> | /novatiers refresh")
                .setStyle(Style.EMPTY.withColor(0x94A3B8)));
    }

    private static MutableText prefix() {
        return Text.empty()
                .append(Text.literal("[Nova Tiers] ").setStyle(Style.EMPTY.withColor(0xF59E0B).withBold(true)));
    }
}
