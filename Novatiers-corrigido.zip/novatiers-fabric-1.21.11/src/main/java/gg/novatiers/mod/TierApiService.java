package gg.novatiers.mod;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class TierApiService {
    private static final Gson GSON = new Gson();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private final Map<String, PlayerTierData> cache = new ConcurrentHashMap<>();
    private final AtomicBoolean refreshing = new AtomicBoolean(false);
    private volatile long lastUpdatedEpochMs = 0L;

    public static class PlayerTierData {
        public final String id;
        public final String name;
        public final String region;
        public final String guild;
        public final int points;
        public final String combatTitle;
        public final String bestMode;
        public final String bestTier;
        public final Map<String, String> tiers;

        public PlayerTierData(
                String id,
                String name,
                String region,
                String guild,
                int points,
                String combatTitle,
                String bestMode,
                String bestTier,
                Map<String, String> tiers
        ) {
            this.id = id;
            this.name = name;
            this.region = region;
            this.guild = guild;
            this.points = points;
            this.combatTitle = combatTitle;
            this.bestMode = bestMode;
            this.bestTier = bestTier;
            this.tiers = Collections.unmodifiableMap(tiers);
        }

        public String getTierForMode(String mode) {
            String normalized = TierColorHelper.normalizeMode(mode);
            if ("overall".equals(normalized)) {
                return bestTier;
            }
            return tiers.get(normalized);
        }
    }

    public PlayerTierData getCachedPlayer(String nick) {
        if (nick == null || nick.isBlank()) return null;
        return cache.get(nick.trim().toLowerCase(Locale.ROOT));
    }

    public int getCachedCount() {
        return cache.size();
    }

    public long getLastUpdatedEpochMs() {
        return lastUpdatedEpochMs;
    }

    public CompletableFuture<Integer> refreshAllAsync(String apiBaseUrl) {
        if (!refreshing.compareAndSet(false, true)) {
            return CompletableFuture.completedFuture(cache.size());
        }

        String endpoint = apiBaseUrl + "/api/mod/tiers";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .timeout(Duration.ofSeconds(8))
                .header("Accept", "application/json")
                .header("User-Agent", "NovaTiersMod/1.0 (Minecraft 1.21.11)")
                .GET()
                .build();

        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .thenApply(response -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        throw new IllegalStateException("HTTP " + response.statusCode());
                    }
                    JsonObject root = GSON.fromJson(response.body(), JsonObject.class);
                    if (root == null || !root.has("players") || !root.get("players").isJsonArray()) {
                        throw new IllegalStateException("Resposta JSON inválida de /api/mod/tiers");
                    }

                    Map<String, PlayerTierData> next = new HashMap<>();
                    JsonArray arr = root.getAsJsonArray("players");
                    for (JsonElement elem : arr) {
                        if (!elem.isJsonObject()) continue;
                        PlayerTierData parsed = parsePlayerObject(elem.getAsJsonObject());
                        if (parsed != null) {
                            next.put(parsed.name.toLowerCase(Locale.ROOT), parsed);
                        }
                    }

                    cache.clear();
                    cache.putAll(next);
                    lastUpdatedEpochMs = System.currentTimeMillis();
                    return next.size();
                })
                .whenComplete((res, err) -> refreshing.set(false));
    }

    public CompletableFuture<PlayerTierData> fetchSinglePlayerAsync(String apiBaseUrl, String nick) {
        String encoded = URLEncoder.encode(nick.trim(), StandardCharsets.UTF_8);
        String endpoint = apiBaseUrl + "/api/mod/player/" + encoded;
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .timeout(Duration.ofSeconds(6))
                .header("Accept", "application/json")
                .header("User-Agent", "NovaTiersMod/1.0 (Minecraft 1.21.11)")
                .GET()
                .build();

        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                .thenApply(response -> {
                    if (response.statusCode() == 404) {
                        return null;
                    }
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        throw new IllegalStateException("HTTP " + response.statusCode());
                    }
                    JsonObject root = GSON.fromJson(response.body(), JsonObject.class);
                    if (root == null || !root.has("player") || !root.get("player").isJsonObject()) {
                        return null;
                    }
                    PlayerTierData parsed = parsePlayerObject(root.getAsJsonObject("player"));
                    if (parsed != null) {
                        cache.put(parsed.name.toLowerCase(Locale.ROOT), parsed);
                    }
                    return parsed;
                });
    }

    private static PlayerTierData parsePlayerObject(JsonObject obj) {
        String name = obj.has("name") && !obj.get("name").isJsonNull() ? obj.get("name").getAsString() : null;
        if (name == null || name.isBlank()) return null;

        String id = obj.has("id") && !obj.get("id").isJsonNull() ? obj.get("id").getAsString() : name.toLowerCase(Locale.ROOT);
        String region = obj.has("region") && !obj.get("region").isJsonNull() ? obj.get("region").getAsString() : "SA";
        String guild = obj.has("guild") && !obj.get("guild").isJsonNull() ? obj.get("guild").getAsString() : "";
        int points = obj.has("points") && !obj.get("points").isJsonNull() ? obj.get("points").getAsInt() : 0;
        String combatTitle = obj.has("combatTitle") && !obj.get("combatTitle").isJsonNull()
                ? obj.get("combatTitle").getAsString()
                : "Iniciante";
        String bestMode = obj.has("bestMode") && !obj.get("bestMode").isJsonNull()
                ? obj.get("bestMode").getAsString()
                : "";
        String bestTier = obj.has("bestTier") && !obj.get("bestTier").isJsonNull()
                ? obj.get("bestTier").getAsString()
                : "";

        Map<String, String> tiers = new HashMap<>();
        if (obj.has("tiers") && obj.get("tiers").isJsonObject()) {
            JsonObject tiersObj = obj.getAsJsonObject("tiers");
            for (String key : tiersObj.keySet()) {
                JsonElement val = tiersObj.get(key);
                if (val != null && !val.isJsonNull()) {
                    tiers.put(key.toLowerCase(Locale.ROOT), val.getAsString());
                }
            }
        }

        if (bestTier.isEmpty() && !tiers.isEmpty()) {
            int bestIdx = 999;
            for (Map.Entry<String, String> e : tiers.entrySet()) {
                int idx = TierColorHelper.getTierOrderIndex(e.getValue());
                if (idx < bestIdx) {
                    bestIdx = idx;
                    bestTier = e.getValue();
                    bestMode = e.getKey();
                }
            }
        }

        return new PlayerTierData(id, name, region, guild, points, combatTitle, bestMode, bestTier, tiers);
    }
}
