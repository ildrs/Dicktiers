package gg.novatiers.mod.mixin;

import gg.novatiers.mod.NovaTiersClientMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Nametag usa Entity#getDisplayName, então é o ponto mais estável entre versões.
@Mixin(Entity.class)
public abstract class EntityRendererMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void novatiers$nametagTier(CallbackInfoReturnable<Text> cir) {
        if (!((Object) this instanceof PlayerEntity player)) return;
        Text original = cir.getReturnValue();
        if (original == null) return;

        Text badge = NovaTiersClientMod.buildPlayerPrefix(player.getGameProfile().name(), true);
        if (badge != null) {
            cir.setReturnValue(Text.empty().append(badge).append(original));
        }
    }
}
