package gg.novatiers.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class NovaTiersConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("novatiers.json");

    public String apiBaseUrl = "https://nova-tiers.ai.studio";
    public String activeMode = "overall";
    public boolean enabled = true;
    public boolean showInNametag = true;
    public boolean showInTabList = true;
    public boolean showPointsInOverall = false;
    public int refreshIntervalSeconds = 120;

    public static NovaTiersConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String raw = Files.readString(CONFIG_PATH, StandardCharsets.UTF_8);
                NovaTiersConfig parsed = GSON.fromJson(raw, NovaTiersConfig.class);
                if (parsed != null) {
                    parsed.sanitize();
                    return parsed;
                }
            } catch (Exception ignored) {
                // Fallback to default config if malformed
            }
        }
        NovaTiersConfig defaults = new NovaTiersConfig();
        defaults.save();
        return defaults;
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    private void sanitize() {
        if (apiBaseUrl == null || apiBaseUrl.isBlank()) {
            apiBaseUrl = "https://nova-tiers.ai.studio";
        }
        apiBaseUrl = apiBaseUrl.trim().replaceAll("/+$", "");
        if (activeMode == null || !TierColorHelper.isValidMode(activeMode)) {
            activeMode = "overall";
        } else {
            activeMode = activeMode.toLowerCase();
        }
        if (refreshIntervalSeconds < 30) {
            refreshIntervalSeconds = 30;
        }
    }
}
